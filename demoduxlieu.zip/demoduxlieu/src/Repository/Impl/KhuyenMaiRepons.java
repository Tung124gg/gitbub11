/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository.Impl;

import DomainModel.KhuyenMai;
import DomainModel.SanPhamChiTiet;
import Repository.IkhuyenMairepons;
import Utiliti.DBConnection;
import Utiliti.JDBCHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author Admin
 */
public class KhuyenMaiRepons implements IkhuyenMairepons {

    DBConnection Connection;

    @Override
    public ArrayList<KhuyenMai> getListFormDB() {
        ArrayList<KhuyenMai> khuyenmai = new ArrayList<>();

        try (Connection con = Connection.getConnection(); PreparedStatement ps = con.prepareStatement(
                "Select ID,IDSP,MAKM,TENKM,MUCGIAMGIA,THOIGIANBATDAU,THOIGIANKETTHUC,TRANGTHAIKM,SOLUONG\n"
                + "from KHUYENMAI ")) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                KhuyenMai km = new KhuyenMai();
                km.setIdKM(rs.getObject(1, UUID.class));
                km.setIDSP(rs.getObject(2, UUID.class));
                km.setMaKM(rs.getString(3));
                km.setTenKM(rs.getString(4));
                km.setMucGiamGia(rs.getFloat(5));
                km.setThoiGianBatDau(rs.getDate(6));
                km.setThoiGianKetThuc(rs.getDate(7));
                km.setTrangThai(rs.getInt(8));
                km.setSoLuong(rs.getInt(9));

                khuyenmai.add(km);
            }

        } catch (Exception e) {
        }
        return khuyenmai;
    }

//    @Override
//    public Boolean add(KhuyenMai km) {
//         Integer row = 0;
//
//        String sql = "insert into KHUYENMAI (IDSP,MAKM,TENKM,MUCGIAMGIA,THOIGIANBATDAU,THOIGIANKETTHUC,TRANGTHAIKM,SOLUONG) values \n"
//                + "(?,?,?,?,?,?,?,?,?)";
//
//        try {
//            row = JDBCHelper.executeUpdate(sql,
//                    km.getMaKM(),
//                    km.getTenKM(),
//                    km.getMucGiamGia(),
//                    km.getThoiGianBatDau(),
//                    km.getThoiGianKetThuc(),
//                    km.getTrangThai(),
//                    km.getSoLuong()
//                    
//            );
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
    @Override
    public Boolean add(KhuyenMai km) {

        try (
                Connection con = Connection.getConnection(); PreparedStatement ps = con.prepareStatement("insert into KHUYENMAI "
                + "(MAKM,TENKM,MUCGIAMGIA,THOIGIANBATDAU,THOIGIANKETTHUC,TRANGTHAIKM) values (?,?,?,?,?,?)")) {
//                ps.setString(1, km.setIDSP(IDSP));
            ps.setString(1, km.getMaKM());
            ps.setString(2, km.getTenKM());
            ps.setFloat(3, km.getMucGiamGia());
            ps.setDate(4, new Date(km.getThoiGianBatDau().getTime()));
            ps.setDate(5, new Date(km.getThoiGianKetThuc().getTime()));
            ps.setInt(6, km.getTrangThai());
            ps.executeUpdate();
//            System.out.println(SelectSPByTen(km.getTenKM()));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public Boolean update(KhuyenMai KM) {
        try (
                Connection con = Connection.getConnection(); PreparedStatement ps = con.prepareStatement
        ("UPDATE KHUYENMAI SET TENKM= ? ,MUCGIAMGIA= ? ,THOIGIANBATDAU= ? ,THOIGIANKETTHUC= ? ,TRANGTHAIKM= ? WHERE MAKM= ?")) {
            ps.setString(6, KM.getMaKM());
            ps.setString(1, KM.getTenKM());
            ps.setFloat(2, KM.getMucGiamGia());
            ps.setDate(3, new Date(KM.getThoiGianBatDau().getTime()));
            ps.setDate(4, new Date(KM.getThoiGianKetThuc().getTime()));
            ps.setInt(5, KM.getTrangThai());
            
            ps.executeUpdate();
//            System.out.println(SelectSPByTen(km.getTenKM()));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

//    @Override
//    public ArrayList<KhuyenMai> search() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
//    @Override
//    public ArrayList<KhuyenMai> search(String km) {
//        String query = "select ID,IDSP,MAKM,TENKM,MUCGIAMGIA,THOIGIANBATDAU,THOIGIANKETTHUC,TRANGTHAIKM,SOLUONG\n"
//                + "from KHUYENMAI\n"
//                + "where TENKM = ?";
//        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(query)) {
//            ResultSet rs = ps.executeQuery();
//            ArrayList<KhuyenMai> list = new ArrayList<>();
//            while (rs.next()) {
//                KhuyenMai KM = new KhuyenMai();
//                KM.setIdKM(rs.getObject(1, UUID.class));
//                KM.setIDSP(rs.getObject(2, UUID.class));
//                KM.setMaKM(rs.getString(3));
//                KM.setTenKM(rs.getString(4));
//                KM.setMucGiamGia(rs.getFloat(5));
//                KM.setThoiGianBatDau(rs.getDate(6));
//                KM.setThoiGianKetThuc(rs.getDate(7));
//                KM.setTrangThai(rs.getInt(8));
//                KM.setSoLuong(rs.getInt(9));
//
//                list.add(KM);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace(System.out);
//        }
//        return null;
//    }

    @Override
    public ArrayList<KhuyenMai> search() {
        ArrayList<KhuyenMai> listkm=new ArrayList<>();
       
        try (Connection con = Connection.getConnection(); PreparedStatement ps = con.prepareStatement
        ("select TENKM ,MUCGIAMGIA ,THOIGIANBATDAU ,THOIGIANKETTHUC ,TRANGTHAIKM, WHERE MAKM= ?");) {
            ps.executeUpdate();

            KhuyenMai km = new KhuyenMai();
            ps.setObject(1, km.getMaKM());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                
                km.setTenKM(rs.getString(1));
                km.setMucGiamGia(rs.getFloat(2));
                km.setThoiGianBatDau(rs.getDate(3));
                km.setThoiGianKetThuc(rs.getDate(4));
                km.setTrangThai(rs.getInt(5));
               
                listkm.add(km);
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return listkm;
    }
    

}
